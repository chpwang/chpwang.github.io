#lang s-exp framework/keybinding-lang

;; Optional, non-invasive Raise replacement for DrRacket.
;; Load with Edit > Keybindings > Add User-defined Keybindings...
;; This file does NOT install or alter the upstream drracket-paredit plugin.

(require drracket/tool-lib)

;; Match the upstream plugin's method of locating the current S-expression.
;; Compute all bounds BEFORE modifying the editor contents. In particular,
;; replacing the enclosing expression in one edit avoids the cursor-position
;; drift produced by the old kill-left / kill-right / splice sequence.
(define (raise-target-start ed pos)
  (define forward (send ed get-forward-sexp pos))
  (or (and forward (send ed get-backward-sexp forward))
      (send ed get-backward-sexp pos)
      pos))

(define (fixed-raise ed evt)
  (when (is-a? ed racket:text<%>)
    (define start (raise-target-start ed (send ed get-start-position)))
    (define parent-start (send ed find-up-sexp start))
    (define target-end (send ed get-forward-sexp start))
    (define parent-end
      (and parent-start (send ed get-forward-sexp parent-start)))
    (when (and parent-start target-end parent-end
               (< parent-start start)
               (< start target-end)
               (<= target-end parent-end))
      (define replacement (send ed get-text start target-end))
      (send ed begin-edit-sequence)
      (dynamic-wind
        void
        (lambda ()
          (send ed delete parent-start parent-end)
          (send ed insert replacement parent-start)
          (send ed set-position (+ parent-start (string-length replacement))))
        (lambda () (send ed end-edit-sequence))))))

;; Escape then r: reliable fall-back in any DrRacket Meta configuration.
(keybinding "esc;r" fixed-raise)
;; Option+r with the upstream plugin's compatibility mapping.
(keybinding "?:a:r" fixed-raise)
;; Additional explicit binding, useful if the preceding form does not match.
(keybinding "a:r" fixed-raise)
;; Original Meta binding.
(keybinding "m:r" fixed-raise)
;; Conflict-free diagnostic shortcut if upstream takes precedence for Option+r.
(keybinding "c:c;c:9" fixed-raise)
